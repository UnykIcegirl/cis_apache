# avoid reading from file if escaped \@

${JO:-jo} key="\@timestamp"


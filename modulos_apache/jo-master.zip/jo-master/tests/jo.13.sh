# object: face card jo logo
${JO:-jo} -p name="This is jo" px[]=300 face=%${srcdir:=.}/tests/jo-logo.png meta[width]=300 px[]=300 meta[height]=300 meta[bytes]=8082 meta[type]=png meta[creator]=JP

# basic two values
${JO:-jo} pass=true type=text

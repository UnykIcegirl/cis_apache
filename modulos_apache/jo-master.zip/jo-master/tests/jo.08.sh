# data from file: text
${JO:-jo} program="jo" authors=@${srcdir:=.}/tests/jo-creator.txt

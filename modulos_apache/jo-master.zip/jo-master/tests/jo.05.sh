# nested native
${JO:-jo} a[]=1 a[]=2 geo[lat]=111 geo[lon]=222

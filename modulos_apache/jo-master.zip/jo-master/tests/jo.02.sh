# basic logo (stdin)
echo jo |  ${JO:-jo} -a

# object: geo
${JO:-jo} -p type=location cog=120 t=u lat=48.85833 lon=2.29513 acc=5 tid=JJ tst=1457767154

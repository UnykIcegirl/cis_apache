# array: simple
${JO:-jo} -a spring summer autumn winter

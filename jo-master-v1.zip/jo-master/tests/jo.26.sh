# read from stdin
echo '{"file":"stdin", "jo": true}' | ${JO:-jo} -f -

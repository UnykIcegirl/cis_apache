# read from pipe

echo '["hello world"]' | ${JO:-jo} foo:=-

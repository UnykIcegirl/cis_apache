# version check
[ "$(${JO:-jo} -v)" = "jo 1.6" ]

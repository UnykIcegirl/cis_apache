## "Press" reports

* [Hacker News](https://news.ycombinator.com/item?id=11230023)
* [Lobsters](https://lobste.rs/s/tyehi1/a_shell_command_to_create_json_jo)
* [reddit](https://www.reddit.com/r/programming/comments/49sx6x/a_shell_command_to_create_json_jo)
* [Hacker News](https://news.ycombinator.com/item?id=11272678)
* [Trivium](http://chneukirchen.org/trivium/2016-05-13)

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Didn&#39;t realize I was only half a man while living without it!!!<br><br> <a href="https://t.co/gSsbJtvjDW">https://t.co/gSsbJtvjDW</a></p>&mdash; Andy Fuchs (@tiptronic) <a href="https://twitter.com/tiptronic/status/705747046079340544">March 4, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">The kind of &quot;why didn&#39;t *I* think of this?&quot; <a href="https://t.co/VlDC79midI">https://t.co/VlDC79midI</a></p>&mdash; Yiorgos Adamopoulos (@hakmem) <a href="https://twitter.com/hakmem/status/706181245328293888">March 5, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet" data-lang="en"><p lang="fr" dir="ltr">jq&#39;s companion <a href="https://t.co/vwYwVxwB4S">https://t.co/vwYwVxwB4S</a></p>&mdash; Sylvain (@flyinva) <a href="https://twitter.com/flyinva/status/706567570141351936">March 6, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>


<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr"><a href="https://twitter.com/jpmens">@jpmens</a> <a href="https://twitter.com/miekg">@miekg</a> i Love Jo.</p>&mdash; Robert Weißgraeber (@robert_we) <a href="https://twitter.com/robert_we/status/706182485261086724">March 5, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>


<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">This is brilliant: a super convenient CLI interface to creating JSON output! <a href="https://t.co/jeirtyhUMY">https://t.co/jeirtyhUMY</a></p>&mdash; ma.ttias.be (@mattiasgeniar) <a href="https://twitter.com/mattiasgeniar/status/707152566719782912">March 8, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">jo - generate JSON at the command line. <a href="https://t.co/WfnboVl3BB">https://t.co/WfnboVl3BB</a></p>&mdash; One Thing Well (@onethingwell) <a href="https://twitter.com/onethingwell/status/707611961039704068">March 9, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">jo -p artist=&quot;Vanessa Paradis&quot; song=&quot;Joe le taxi&quot; year=1987</p>&mdash; Frederic Cambus (@fcambus) <a href="https://twitter.com/fcambus/status/707860299467120640">March 10, 2016</a></blockquote> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
